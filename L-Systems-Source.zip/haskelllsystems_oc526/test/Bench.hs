{-# LANGUAGE DeriveGeneric, DeriveAnyClass, StandaloneDeriving #-}
import Test.Tasty.Bench ( defaultMain, Benchmark, bgroup, bench, nf, env )
import GHC.Generics
import Control.DeepSeq

import IC.Colour
import LSystems
import Examples

main :: IO ()
main = defaultMain [benchmarks]


benchmarks :: Benchmark
benchmarks = bgroup "lsystems"
  [ bench "trace1" (nf (\c -> trace1 c 90 Blue) cmds)
  , bench "trace2" (nf (\c -> trace2 c 90 Blue) cmds)
  , bench "newTrace3" (nf (\c -> trace2 c 90 Blue) cmds)
  ]
  where
    !cmds = force (expandLSystem arrowHead 6)

-- 'ere be Dragons
-- This stuff is used to allow for the strict evaluation of Commands and Colours
-- Don't worry about how this works :)
deriving instance Generic Command
deriving instance NFData Command
deriving instance Generic Colour
deriving instance NFData Colour

{- 
  ======================================================
  STUDENT REFLECTION & BENCHMARK ANALYSIS (10 Runs Data)
  ======================================================
  
  Data Summary Table:
  Run | trace1 (us) | trace2 (us) | Total Time (s)
  --------------------------------------------------
   1  |    101      |    100      |     10.33
   2  |    101      |    99.2     |     13.28
   3  |    119      |    155      |     67.19
   4  |    96.5     |    149      |     78.98
   5  |    100      |    100      |     10.46
   6  |    97.7     |    99.2     |      6.63
   7  |    99.0     |    100      |     10.43
   8  |    101      |    98.6     |     10.54
   9  |    97.7     |    98.0     |     10.38
  10  |    96.3     |    161      |     26.72


Mean comparison and final conclusion:
- Trace1 average: ~100.9 us (Median: ~99.5 us)
- Trace2 average: ~116.0 us (Median: ~100.0 us, pulled up by a few high runs)
- Conclusion: 
       In most normal runs, trace1 and trace2 perform almost the same (around 98-100 us). This proves 
       that Haskell's -O2 compiler optimization is very smart. However, trace1 is more stable because 
       it avoids creating lists on the heap, whereas trace2 can be less stable due to memory allocation 
       and cleanup during recursive branching.
-}