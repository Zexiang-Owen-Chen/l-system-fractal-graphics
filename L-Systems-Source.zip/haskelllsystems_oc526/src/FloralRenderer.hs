module FloralRenderer (drawFloralTriangle, drawFloralOutline) where

import IC.Graphics (drawLines)
import FloralPattern (floralLines, floralOutlineLines)

drawFloralTriangle :: Bool -> IO ()
drawFloralTriangle live = drawLines live floralLines

drawFloralOutline :: Bool -> IO ()
drawFloralOutline live = drawLines live floralOutlineLines
