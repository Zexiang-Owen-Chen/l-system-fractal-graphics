module Renderer where

import LSystems
import IC.Colour
import IC.Graphics
import Examples -- to draw it in for REPL auto-import

drawLSystem1 :: Bool -> LSystem -> Int -> Colour -> IO ()
drawLSystem1 liveAction system n colour =
  drawLines liveAction (trace1 (expandLSystem system n) (angle system) colour)

drawLSystem2 :: Bool -> LSystem -> Int -> Colour -> IO ()
drawLSystem2 liveAction system n colour =
  drawLines liveAction (trace2 (expandLSystem system n) (angle system) colour)

drawLSystem3 :: Bool -> LSystem -> Int -> Colour -> IO ()
drawLSystem3 liveAction system n colour =
  drawLines liveAction (newTrace3 (expandLSystem system n) (angle system) colour)

drawCyberTree :: Bool -> LSystem -> Int -> Colour -> IO ()
drawCyberTree liveAction system n colour =
  drawLines liveAction (cyberTrace (expandLSystem system n) (angle system) colour)

drawVibrantMandala :: Bool -> LSystem -> Int -> Colour -> IO () 
drawVibrantMandala liveAction system n colour =
  drawLines liveAction (vibrantTrace (expandLSystem system n) (angle system) colour)

drawLSystemWithProgress :: Bool -> LSystem -> Int -> IO ()
drawLSystemWithProgress liveAction lsys depth = 
    let expandedCmds = expandLSystem lsys depth
        coloredLines = cyberProgressTrace expandedCmds (angle lsys) (Custom 0 0 0)
    in drawLines liveAction coloredLines
