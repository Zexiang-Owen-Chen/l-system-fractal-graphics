{-
L-SYSTEMS GRAPHICS CONTEST — SUBMISSION NOTES

PRIMARY ENTRY: Floral Triangle
Output image: floral.png

In the project's Cabal REPL, load:
    :load src/FloralRenderer.hs

Function call producing the primary output:
    FloralRenderer.drawFloralTriangle False

Contribution and AI disclosure:
I developed the visual concept and composition, designed the outlines
, and specified the combination of triangular scrollwork, floral
elements and colours.

ChatGPT assisted with the implementation, including the curve geometry,
conversion of sampled curves into turtle commands, the custom floralTrace
function, and the colour mapping.

The implementation uses the lab's L-system expansion, parsing and turtle
movement functions, together with the supplied IC.Graphics renderer.
The floral shapes are constructed geometrically and converted into a
long production of M, +, -, [ and ] commands, rather than being primarily
generated through recursive rewriting of short productions. The custom
tracer uses branch depth to control positioning and colour selection.

This floral design is my preferred entry. I have described the method
and AI assistance so that you can judge whether it meets the rules.


CONDITIONAL FALLBACK: Purple Tree Fractal
Output image: purpletree.png

If the floral design is not eligible, please consider this purple design
as my entry instead, if a conditional fallback is permitted.

I independently implemented the tracing and colouring extensions for
this design, using the supplied lab framework and the existing
sciFiCrystal example L-system.

In the project's Cabal REPL, load:
    :load src/Renderer.hs

Function call producing the fallback output:
    drawVibrantMandala True sciFiCrystal 5 (Custom 0 0 0)

I understand that only one output may enter the contest. The purple
design is provided solely as a fallback, not as an additional entry.
-}

module LSystems ( LSystem(LSystem), ColouredLine, Command(..)
                , angle, axiom, rules, lookupChar
                , expandOne, expand, move, parse, trace1, trace2, newTrace3, cyberTrace, vibrantTrace, cyberProgressTrace
                , expandLSystem ) where

import IC.Colour
--import System.Win32 (COORD(xPos))
--import Distribution.Verbosity (verbose)
import Data.Monoid (Last(Last))
--import Text.XHtml (col)

-- Part 1 - Warmup
----------------------------------------------------------
type Rules a = [(Char, [a])]
data LSystem = LSystem Float [Char] (Rules Char)

-- Functions for working with systems. Skeleton optional...

-- Returns the rotation angle for the given system.
angle :: LSystem -> Float
angle (LSystem fl _ _) = fl

-- Returns the axiom string for the given system.
axiom :: LSystem -> [Char]
axiom (LSystem _ ax _) = ax

-- Returns the set of rules for the given system.
rules :: LSystem -> Rules Char
rules (LSystem _ _ rs) = rs

--
-- Pre: the character has a binding in the Rules list
--
lookupChar :: Rules a -> Char -> [a]
lookupChar rs m = concat [q | (p , q) <- rs, p == m]

-- Part 2: Expansion and Parsing
data Command = F | L | R | B [Command] deriving Show

--
-- Expand command string s once using rule table r
--
expandOne :: Rules Char -> [Char] -> [Char]
expandOne rs [] = []
expandOne rs (x:xs) = lookupChar rs x ++ expandOne rs xs

--
-- Expand command string s n times using rule table r
--
expand :: Rules Char -> [Char] -> Int -> [Char]
expand rs xs 0 = xs
expand rs xs n = expand rs (expandOne rs xs) (n-1)

parse :: [Char] -> [Command]
parse str = fst (parseHelper str)
    where
        parseHelper :: [Char] -> ([Command], [Char])
        parseHelper [] = ([], [])
        parseHelper (']':cs) = ([], cs)
        parseHelper ('[':cs) = 
            let (subCmds, rest) = parseHelper cs         
                (restCmds, finalRest) = parseHelper rest 
            in (B subCmds : restCmds, finalRest)         
        parseHelper (c:cs) =
            let cmds = lookupChar commandMap c
                (restCmds, finalRest) = parseHelper cs
            in (cmds ++ restCmds, finalRest)

expandLSystem :: LSystem -> Int -> [Command]
expandLSystem ls n = parse (expand rs cha n)
            where
                rs = rules ls
                cha = axiom ls

-- Part 3: Turtles
type Vertex = (Float, Float)
type TurtleState = (Vertex, Float)
type ColouredLine = (Vertex, Vertex, Colour)

initialState :: TurtleState
initialState = ((0, 0), 90)

-- Move a turtle.
--
-- F moves distance 1 in the current direction.
-- L rotates left according to the given angle.
-- R rotates right according to the given angle.
move :: Command -> Float -> TurtleState -> TurtleState
move L angle (ver , direction) = (ver , direction + angle)
move R angle (ver , direction) = (ver, direction - angle)
move F angle (ver , direction) = ((x + cos t , y + sin t) , direction )
        where
            (x , y) = ver
            t = degreesToRadians direction

trace1 :: [Command] -> Float -> Colour -> [ColouredLine]
trace1 cmds fl col = traceHelper cmds fl col initialState
    where
        traceHelper :: [Command] -> Float -> Colour -> TurtleState -> [ColouredLine]
        traceHelper [] _ _ _ = []
        traceHelper (B subcmds : rescmds) fl col state = 
            let innerLines = traceHelper subcmds fl col state
                restLines = traceHelper rescmds fl col state
            in innerLines ++ restLines
        traceHelper (x : xs) fl col state =
            let newstate = move x fl state
            in if fst state == fst newstate 
                then traceHelper xs fl col newstate 
                else (fst state , fst newstate , col) : traceHelper xs fl col newstate

-- This version uses an explicit stack of residual commands and turtle states
type Stack = [([Command], TurtleState)]
trace2 :: [Command] -> Float -> Colour -> [ColouredLine]
trace2 cmds fl col = traceHelper2 cmds fl col initialState []
    where
        traceHelper2 :: [Command] -> Float -> Colour -> TurtleState -> Stack -> [ColouredLine]
        traceHelper2 [] _ _ _ [] = []
        traceHelper2 [] fl col state (x:xs) = traceHelper2 restcmds fl col state xs 
            where (restcmds , state) = x 
        traceHelper2 (B subcmds : restcmds) fl col state stk =
            let newstk = (restcmds , state) : stk 
            in traceHelper2 subcmds fl col state newstk
        traceHelper2 (x : xs) fl col state stk =
            let newstate = move x fl state 
            in if fst state == fst newstate 
                then traceHelper2 xs fl col newstate stk 
                else (fst state , fst newstate , col) : traceHelper2 xs fl col newstate stk

-- Provided Helper Functions
------------------------------------------------------------------------------

degreesToRadians :: Float -> Float
degreesToRadians x = (x / 180) * pi

commandMap :: Rules Command
commandMap = [ ('M', [F])
             , ('N', [F])
             , ('X', [])
             , ('Y', [])
             , ('A', [])
             , ('+', [L])
             , ('-', [R])
             ]

{- 
  ======================================================
  STUDENT REFLECTION & BENCHMARK ANALYSIS (10 Runs Data)
  ======================================================
  
  Data Summary Table:
  Run | trace1 (us) | trace2 (us) | Total Time (s)
  --------------------------------------------------
   1  |    101      |    100      |     10.33
   2  |    101      |    99.2     |     13.28
   3  |    119      |    155      |     67.19
   4  |    96.5     |    149      |     78.98
   5  |    100      |    100      |     10.46
   6  |    97.7     |    99.2     |      6.63
   7  |    99.0     |    100      |     10.43
   8  |    101      |    98.6     |     10.54
   9  |    97.7     |    98.0     |     10.38
  10  |    96.3     |    161      |     26.72


Mean comparison and final conclusion:
- Trace1 average: ~100.9 us (Median: ~99.5 us)
- Trace2 average: ~116.0 us (Median: ~100.0 us, pulled up by a few high runs)
- Conclusion: 
       In most normal runs, trace1 and trace2 perform almost the same (around 98-100 us). This proves 
       that Haskell's -O2 compiler optimization is very smart. However, trace1 is more stable because 
       it avoids creating lists on the heap, whereas trace2 can be less stable due to memory allocation 
       and cleanup during recursive branching.
-}
--Vary the colour of lines traced by the turtle
depthToColour :: Int -> Colour
depthToColour depth =
    let d = fromIntegral depth
    in Custom 0.3 (min 1.0 (0.2 + d * 0.15)) 0.1

type NewTurtleState = (Vertex , Float , Int)

newInitialState :: NewTurtleState
newInitialState = ((0 , 0) , 90 , 0)

newmove :: Command -> Float -> NewTurtleState -> NewTurtleState
newmove L angle (ver , direction , depth) = (ver , direction + angle , depth)
newmove R angle (ver , direction , depth) = (ver, direction - angle , depth)
newmove F angle (ver , direction , depth) = ((x + cos t , y + sin t) , direction , depth)
         where
            (x , y) = ver
            t = degreesToRadians direction


type NewStack = [([Command] , NewTurtleState)]

newTrace2 :: [Command] -> Float -> Colour -> [ColouredLine]
newTrace2 cmds fl _col = newTrace2Helper cmds fl newInitialState []
    where
        newTrace2Helper :: [Command] -> Float -> NewTurtleState -> NewStack -> [ColouredLine]
        newTrace2Helper [] _ _ [] = []
        newTrace2Helper [] fl _ (x : xs) = newTrace2Helper restcmds fl backstate xs 
            where
                (restcmds , backstate) = x
        newTrace2Helper (B subcmds : restcmds) fl state stk =
            let newstk = (restcmds , state) : stk 
                (ver , flo , depth) = state
                newstate = (ver , flo , depth + 1)
            in newTrace2Helper subcmds fl newstate newstk
        newTrace2Helper (x : xs) fl state stk =
            let newstate = newmove x fl state
                (v1 , _ , depth) = state
                (v2 , _ , _) = newstate 
            in if v1 == v2 
                then newTrace2Helper xs fl newstate stk 
                else (v1 , v2 , depthToColour depth) : newTrace2Helper xs fl newstate stk 

--Using tail recursion and accumulator and varying the color
newTrace3 :: [Command] -> Float -> Colour -> [ColouredLine]
newTrace3 cmds fl _col = newTrace3Helper cmds fl newInitialState [] []
    where
        newTrace3Helper :: [Command] -> Float -> NewTurtleState -> NewStack -> [ColouredLine] -> [ColouredLine]
        newTrace3Helper [] _ _ [] acc = reverse acc
        newTrace3Helper [] fl _ (x : xs) acc = newTrace3Helper restcmds fl backstate xs acc 
            where
                (restcmds, backstate) = x
        newTrace3Helper (B subcmds : restcmds) fl state stk acc =
            let newStk = (restcmds, state) : stk 
                (ver, flo, depth) = state
                subState = (ver, flo, depth + 1)
            in newTrace3Helper subcmds fl subState newStk acc
        newTrace3Helper (x : xs) fl state stk acc =
            let newState = newmove x fl state
                (v1, _, depth) = state
                (v2, _, _) = newState 
            in if v1 == v2 
                then newTrace3Helper xs fl newState stk acc
                else 
                    let line = (v1, v2, depthToColour depth)
                        newAcc = line : acc  
                    in newAcc `seq` newTrace3Helper xs fl newState stk newAcc


cyberDepthToColour :: Int -> Colour
cyberDepthToColour depth =
    let d = fromIntegral depth
    in Custom (min 1.0 (0.1 + d * 0.15))   
              (min 1.0 (0.5 + d * 0.12))   
              (min 1.0 (1.0 - d * 0.05))   

cyberTrace :: [Command] -> Float -> Colour -> [ColouredLine]
cyberTrace cmds fl _col = newTrace3Helper cmds fl newInitialState [] []
    where
        newTrace3Helper [] _ _ [] acc = reverse acc
        newTrace3Helper [] fl _ (x : xs) acc = newTrace3Helper restcmds fl backstate xs acc 
            where
                (restcmds, backstate) = x
        newTrace3Helper (B subcmds : restcmds) fl state stk acc =
            let newStk = (restcmds, state) : stk 
                (ver, flo, depth) = state
                subState = (ver, flo, depth + 1)
            in newTrace3Helper subcmds fl subState newStk acc
        newTrace3Helper (x : xs) fl state stk acc =
            let newState = newmove x fl state
                (v1, _, depth) = state
                (v2, _, _) = newState 
            in if v1 == v2 
                then newTrace3Helper xs fl newState stk acc
                else 
                    let line = (v1, v2, cyberDepthToColour depth) 
                        newAcc = line : acc  
                    in newAcc `seq` newTrace3Helper xs fl newState stk newAcc


vibrantDepthToColour :: Int -> Colour
vibrantDepthToColour depth =
    let d = fromIntegral depth
    in Custom (min 1.0 (0.3 + sin (d * 0.6) * 0.4 + 0.3))   -- Red
              (min 1.0 (0.4 + cos (d * 0.4) * 0.4 + 0.2))   -- Green
              (min 1.0 (0.6 + d * 0.1))                     -- Blue

vibrantTrace :: [Command] -> Float -> Colour -> [ColouredLine]
vibrantTrace cmds fl _col = vibrantTraceHelper cmds fl newInitialState [] []
    where
        vibrantTraceHelper :: [Command] -> Float -> NewTurtleState -> NewStack -> [ColouredLine] -> [ColouredLine]
        vibrantTraceHelper [] _ _ [] acc = reverse acc
        vibrantTraceHelper [] fl _ (x : xs) acc = vibrantTraceHelper restcmds fl backstate xs acc 
            where
                (restcmds, backstate) = x
        vibrantTraceHelper (B subcmds : restcmds) fl state stk acc =
            let newStk = (restcmds, state) : stk 
                (ver, flo, depth) = state
                subState = (ver, flo, depth + 1)
            in vibrantTraceHelper subcmds fl subState newStk acc
        vibrantTraceHelper (x : xs) fl state stk acc =
            let newState = newmove x fl state
                (v1, _, depth) = state
                (v2, _, _) = newState 
            in if v1 == v2 
                then vibrantTraceHelper xs fl newState stk acc
                else 
                    let line = (v1, v2, vibrantDepthToColour depth)
                        newAcc = line : acc  
                    in newAcc `seq` vibrantTraceHelper xs fl newState stk newAcc


progressToCyberColour :: Int -> Int -> Colour
progressToCyberColour index total =
    let p = fromIntegral index / max 1.0 (fromIntegral total)
    in Custom (min 1.0 (0.1 + p * 0.9))   
              (min 1.0 (0.5 + p * 0.5))   
              (min 1.0 (1.0 - p * 0.8))   

cyberProgressTrace :: [Command] -> Float -> Colour -> [ColouredLine]
cyberProgressTrace cmds fl col = 
    let rawLines = newTrace3 cmds fl col  
        totalLines = length rawLines
    in zipWith (\i (v1, v2, _) -> (v1, v2, progressToCyberColour i totalLines)) [0..] rawLines