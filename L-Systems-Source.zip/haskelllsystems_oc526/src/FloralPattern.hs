{-# LANGUAGE BangPatterns #-}
module FloralPattern
  ( floralTriangle, floralTrace, floralColour, floralLines
  , floralOutlineLines, squareFrame
  ) where

import LSystems (LSystem(..), Command(..), ColouredLine, expandLSystem, move)
import IC.Colour (Colour(..))
import Data.List (foldl', groupBy, sortOn)

-- X expands once to a numerically constructed production. Further iterations
-- preserve it. This is NOT a recursive botanical growth grammar.
floralTriangle :: LSystem
floralTriangle = LSystem 0.5 "X"
  (('X', encodeDrawing drawing) : [(c, [c]) | c <- "M+-[]"])

-- One turtle step is 1/3 of a design unit. Increase to 4 or 5 for large
-- windows; the turtle itself still advances exactly ONE unit each time.
samplingScale :: Float
samplingScale = 3

type Point = (Double, Double)
type Stroke = (Int, [Point])
type State = ((Float, Float), Float)

-- Palette: 0 blue, 1 violet, 2 pink, 3 stem, 4 ivory, 5 gold, 6 lilac.
-- Bracket protocol: depth 1 = reposition without emitting a line;
-- depth 2..8 = palette 0..6. Intermediate brackets contain no movement.
-- This is handled ONLY by floralTrace. Ordinary tracers also draw travel.
floralTrace :: [Command] -> Float -> Colour -> [ColouredLine]
floralTrace commands turn _ = walk commands ((0,0),90) 0 []
  where
    walk [] _ _ [] = []
    walk [] _ _ ((rest, saved, depth):stack) = walk rest saved depth stack
    walk (B branch:rest) state depth stack =
      walk branch state (depth+1) ((rest,state,depth):stack)
    walk (command:rest) state depth stack =
      let !next = move command turn state
          from = fst state
          to = fst next
          continuation = walk rest next depth stack
      in case command of
           F | depth >= 2 ->
             (from, to, floralColour (depth-2) (midpoint from to)) : continuation
           _ -> continuation
    midpoint (x,y) (u,v) = ((x+u)/2, (y+v)/2)

-- Spatial colouring makes all three rotated sectors match. Each tiny line
-- has a constant colour, exactly as required by the existing IC.Graphics.
floralColour :: Int -> (Float,Float) -> Colour
floralColour palette (xx,yy) =
  let x = xx / samplingScale
      y = yy / samplingScale
      radius = sqrt (x*x+y*y)
      theta = atan2 x y
      t = 0.5 + 0.5 * sin (radius * 0.035 + 0.65 * cos (3*theta))
      (a,b) = case palette of
        0 -> ((0.12,0.27,0.96), (0.38,0.91,1.00))
        1 -> ((0.29,0.10,0.64), (0.78,0.47,1.00))
        2 -> ((0.53,0.12,0.85), (1.00,0.43,0.78))
        3 -> ((0.19,0.26,0.20), (0.60,0.57,0.30))
        4 -> ((0.72,0.60,0.44), (1.00,0.97,0.87))
        5 -> ((0.71,0.36,0.10), (1.00,0.85,0.43))
        _ -> ((0.42,0.30,0.65), (0.86,0.80,0.96))
  in blend t a b
  where
    blend t (r,g,b) (u,v,w) =
      Custom (r+(u-r)*t) (g+(v-g)*t) (b+(w-b)*t)

floralLines :: [ColouredLine]
floralLines = squareFrame (floralTrace (expandLSystem floralTriangle 1) 0.5 White)

-- A simpler view for checking the structure against the first reference.
floralOutlineLines :: [ColouredLine]
floralOutlineLines = squareFrame
  [(a,b,Custom 0.90 0.84 0.99) | (a,b,_) <-
    floralTrace (expandLSystem outlineSystem 1) 0.5 White]
  where
    outlineSystem = LSystem 0.5 "X"
      (('X',encodeDrawing skeleton) : [(c,[c]) | c <- "M+-[]"])

-- Black zero-length segments provide margin and a square bounding box.
-- A square display window preserves the shape in the existing renderer.
squareFrame :: [ColouredLine] -> [ColouredLine]
squareFrame [] = []
squareFrame lines0 =
  let points = concatMap (\(p,q,_) -> [p,q]) lines0
      xs = map fst points
      ys = map snd points
      loX = minimum xs; hiX = maximum xs
      loY = minimum ys; hiY = maximum ys
      cx = (loX+hiX)/2; cy = (loY+hiY)/2
      r = 0.54 * max (hiX-loX) (hiY-loY)
      corners = [(cx-r,cy-r),(cx+r,cy+r)]
  in [(p,p,Black) | p <- corners] ++ lines0

-- Build one 120-degree sector and rotate it three times.
drawing, skeleton :: [Stroke]
drawing = threefold (frame ++ scrolls ++ pendant ++ lily ++ sprigs)
       ++ threefold (map (mapStroke (scale 0.37)) innerLace)
       ++ threefold (map (mapStroke (scale 0.14)) innerLace)
skeleton = threefold (take 1 frame ++ take 1 innerLace ++ scrolls ++ pendant)

threefold :: [Stroke] -> [Stroke]
threefold strokes = concat
  [map (mapStroke (rotate (fromIntegral k * 2*pi/3))) strokes | k <- [0..2::Int]]

mapStroke :: (Point -> Point) -> Stroke -> Stroke
mapStroke f (colour,points) = (colour,map f points)

top, corner :: Point
top = (0,240)
corner = (120*sqrt 3,-120)

edge :: Double -> Point
edge = bezier top (edgeControl 0.30 105) (edgeControl 0.70 105) corner

-- Symmetric control points: chord position plus outward normal offset.
edgeControl :: Double -> Double -> Point
edgeControl along outward = add (add top (scale along (sub corner top)))
  (scale outward (sqrt 3/2,0.5))

edgeTangent :: Double -> Point
edgeTangent t = unit (sub (edge (t+0.0001)) (edge (t-0.0001)))

frame :: [Stroke]
frame =
  [ (if abs offset <= 4 then 0 else 1,
      [add (edge t) (scale (offset*sin(pi*t)) (normal (edgeTangent t)))
      | i <- [0..1800::Int], let t = fromIntegral i/1800])
  | offset <- [0,-2,2,-4,4,-6,6]] ++ innerLace

innerLace :: [Stroke]
innerLace = [(1, cubic top (edgeControl 0.30 (-250)) (edgeControl 0.70 (-250)) corner)]

scrolls :: [Stroke]
scrolls = concat [map (mapStroke (mirror side)) oneSide | side <- [-1,1]]
  where
    oneSide =
      [ (1, chain top
          [((8,290),(80,365),(122,347))
          ,((165,332),(154,284),(123,283))
          ,((95,281),(97,310),(113,310))
          ,((127,310),(125,293),(115,296))])
      , (0, chain top
          [((18,283),(86,352),(121,335))
          ,((145,322),(142,294),(123,293))
          ,((108,292),(108,302),(115,296))])
      , (1, chain top
          [((10,267),(42,296),(63,282))
          ,((81,269),(58,252),(48,263))
          ,((42,269),(49,280),(55,273))])
      , (5, cubic top (12,278) (17,302) (26,318))]

-- Small inward-facing fleur-de-lis ornaments from the sketch.
pendant :: [Stroke]
pendant = [(5,chain (0,233)
  [((-2,212),(-16,198),(0,181)),((16,198),(2,212),(0,233))])]
  ++ concat [map (mapStroke (mirror side)) half | side <- [-1,1]]
  where
    half =
      [(6,chain (0,174)
        [((-9,191),(-39,183),(-37,163))
        ,((-35,146),(-15,150),(-19,163))
        ,((-22,169),(-30,164),(-25,159))
        ,((-29,153),(-12,150),(-5,164))])
      ,(5,chain (-5,162)
        [((-6,151),(-2,147),(-6,142))
        ,((-18,140),(-21,134),(-21,119))
        ,((-22,107),(-28,103),(-30,108))
        ,((-34,97),(-22,99),(-17,110))
        ,((-13,119),(-16,133),(-4,133))
        ,((-3,121),(-2,111),(-3,103))
        ,((-11,107),(-10,98),(0,94))])]

-- Long outer petals, shorter ivory petals and golden stamens.
-- Dense narrow curves across each petal approximate shaded fill using lines.
lily :: [Stroke]
lily = [(3,cubic top (3,269) (-3,291) base)]
    ++ concat [petal 6 base a len width 6 | (a,len,width) <- outerPetals]
    ++ concat [petal 4 base a len width 16 | (a,len,width) <- middlePetals]
    ++ concat [petal 4 base a len width 20 | (a,len,width) <- frontPetals]
    ++ concat [stamen k | k <- [-9..9::Int]]
  where
    base = (0,302)
    outerPetals =
      [(a,104-0.20*abs a,6.5) | a <- [-100,-80..100]]
    middlePetals =
      [(a,106-0.40*abs a,13.5) | a <- [-64,-48..64]]
    frontPetals =
      [(a,68-0.23*abs a,13) | a <- [-65,-39,-13,13,39,65]]
    stamen k =
      let x = fromIntegral k * 2.2
          tip = (x, 346 + 12*cos (fromIntegral k*0.42))
      in [(5,cubic base (x*0.3,320) (x*0.8,339) tip)]
        ++ [(5,circle tip 1.3)]

-- Angles are measured from local upward direction.
petal :: Int -> Point -> Double -> Double -> Double -> Int -> [Stroke]
petal colour base degrees len width density =
  let a = degrees*pi/180
      u = (sin a,cos a)
      v = (cos a,-sin a)
      at x y = add base (add (scale x v) (scale y u))
      tip = at (0.12*width*sin (2*a)) len
      curve q = cubic base (at (q*width) (len*0.22))
                            (at (q*width) (len*0.76)) tip
      veins = [(colour,curve (fromIntegral i/fromIntegral density))
              | i <- [-density..density]]
  in veins ++ [(if colour==4 then 6 else if colour==6 then 5 else colour,curve (-1)),
               (if colour==6 then 2 else colour,curve 1)]

-- Flowering sprigs along the three outer edges.
sprigs :: [Stroke]
sprigs = concat [sprig t i | (t,i) <- zip [0.16,0.29,0.43,0.57,0.71,0.84] [0..]]
  where
    sprig t index =
      let p = edge t
          tangent = edgeTangent t
          out = normal tangent
          size = 43 + 9*sin (fromIntegral index*1.7)
          at x y = add p (add (scale x tangent) (scale y out))
          spine = cubic p (at (-6) (size*0.30)) (at 7 (size*0.75)) (at 0 size)
          blossom j =
            let h = fromIntegral j / 5
                side = if even j then 1 else -1
                start = at (2*sin (h*pi)) (size*h*0.8)
                centre = at (side*(12+7*h)) (size*(0.25+0.70*h))
                radius = 5.0 + 3.0*sin (h*pi)
            in [(3,cubic start (add start (scale 9 out))
                      (sub centre (scale 5 out)) centre)]
               ++ flower centre radius (fromIntegral (index+j)*0.71)
          leaf j =
            let h = fromIntegral j / 4
                p0 = at 0 (size*h)
                side = if even j then 1 else -1
                tip = at (side*10) (size*h+13)
            in [(3,cubic p0 (at (side*9) (size*h+2))
                                  (at (side*12) (size*h+8)) tip),
                (5,cubic p0 (at (side*3) (size*h+6))
                                  (at (side*7) (size*h+12)) tip)]
      in [(3,spine)] ++ concatMap leaf [1..3::Int]
           ++ concatMap blossom [1..5::Int]
           ++ flower (at 0 size) 5.5 0

flower :: Point -> Double -> Double -> [Stroke]
flower centre radius phase = concat
  [petal (if even k then 2 else 1) centre
         (phase*180/pi + fromIntegral k*72) radius (radius*0.56) 5
  | k <- [0..4::Int]]
  ++ [(5,circle centre (radius*0.13))]
  ++ [(5,[centre, add centre (scale (radius*0.30) (cos a,sin a))])
     | k <- [0..4::Int], let a = phase+fromIntegral k*2*pi/5]

-- Cubic curves are sampled densely, then followed by the fixed-unit turtle.
bezier :: Point -> Point -> Point -> Point -> Double -> Point
bezier p a b q t =
  let u = 1-t
  in add (add (scale (u*u*u) p) (scale (3*u*u*t) a))
         (add (scale (3*u*t*t) b) (scale (t*t*t) q))

cubic :: Point -> Point -> Point -> Point -> [Point]
cubic p a b q =
  let n = max 12 (ceiling (4 * (distance p a + distance a b + distance b q)))
  in [bezier p a b q (fromIntegral i/fromIntegral n) | i <- [0..n::Int]]

chain :: Point -> [(Point,Point,Point)] -> [Point]
chain p [] = [p]
chain p ((a,b,q):rest) = cubic p a b q ++ drop 1 (chain q rest)

circle :: Point -> Double -> [Point]
circle p r = [add p (r*cos a,r*sin a) | i <- [0..96::Int],
              let a = fromIntegral i*2*pi/96]

add, sub :: Point -> Point -> Point
add (x,y) (u,v) = (x+u,y+v)
sub (x,y) (u,v) = (x-u,y-v)
scale :: Double -> Point -> Point
scale s (x,y) = (s*x,s*y)
distance :: Point -> Point -> Double
distance p q = let (x,y)=sub p q in sqrt (x*x+y*y)
unit :: Point -> Point
unit p = scale (1/max 1e-12 (distance p (0,0))) p
normal :: Point -> Point
normal (x,y) = (-y,x)
rotate :: Double -> Point -> Point
rotate a (x,y) = (x*cos a-y*sin a,x*sin a+y*cos a)
mirror :: Double -> Point -> Point
mirror s (x,y) = (s*x,y)

-- Shared starting points are grouped to reduce repositioning commands.
encodeDrawing :: [Stroke] -> String
encodeDrawing strokes = concatMap encodeGroup grouped
  where
    nonempty = [(p,(c,ps)) | (c,ps@(p:_)) <- strokes]
    grouped = groupBy (\a b -> fst a == fst b) (sortOn fst nonempty)
    encodeGroup [] = ""
    encodeGroup entries@((p,_):_) =
      let paths = map snd entries
          (travel,state) = follow ((0,0),90) [p]
          encodePath (palette,ps) =
            let (commands,_) = follow state ps
                nesting = palette+1
            in replicate nesting '[' ++ commands ++ replicate nesting ']'
      in "[" ++ travel ++ concatMap encodePath paths ++ "]"

-- Error feedback leaves each sampled target within one unit step.
-- The nearest permitted heading has error <= 0.25 degrees.
-- Use the SAME move function as the existing tracer, so the numerical
-- construction and actual turtle follow exactly the same movement rules.
follow :: State -> [Point] -> (String,State)
follow state points =
  let (!end,chunks) = foldl' target (state,[]) points
  in (concat (reverse chunks),end)
  where
    target (!current,acc) (px,py) =
      advance (realToFrac px*samplingScale, realToFrac py*samplingScale) current acc
    advance dest@(!tx,!ty) state0@((!x,!y),!heading) acc
      | (tx-x)*(tx-x)+(ty-y)*(ty-y) < 1 = (state0,acc)
      | otherwise =
          let wanted = atan2 (ty-y) (tx-x) * 180/pi
              ticks = round ((wanted-heading)/0.5) :: Int
              turnTicks = (ticks+360) `mod` 720-360
              command = if turnTicks >= 0 then L else R
              symbol = if turnTicks >= 0 then '+' else '-'
              turned = iterateTurn (abs turnTicks) command state0
              !next = move F 0.5 turned
              chunk = replicate (abs turnTicks) symbol ++ "M"
          in advance dest next (chunk:acc)
    iterateTurn 0 _ !s = s
    iterateTurn n c !s = iterateTurn (n-1) c (move c 0.5 s)
